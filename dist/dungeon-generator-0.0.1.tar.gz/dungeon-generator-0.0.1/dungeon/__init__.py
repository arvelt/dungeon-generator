__all__ = ['Generator']
from .DungeonGenerator import Generator
